
#!bin/bash
#[2022-10-07T09:33:10+0000]

start="9:33:10 7-10-2022"
date=$(date +%Y%m%d)
let DIFF=(`date +%s -d $date`-`date +%s -d  20221007`)/86400


echo "Installed $DIFF Day ago" 


