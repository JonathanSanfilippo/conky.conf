#!/bin/bash

date=$(date +%Y-%m-%d --date="7 day ago")
date2=$(date +%Y-%m-%d)

url="http://webservices.ingv.it/fdsnws/event/1/query?starttime=$date""T00%3A00%3A00&endtime=$date2""T23%3A59%3A59&minmag=5&maxmag=10&mindepth=-10&maxdepth=1000&minlat=-90&maxlat=90&minlon=-180&maxlon=180&minversion=100&orderby=time-asc&timezone=UTC&format=text&limit=10000"

wget -o ~/.config/conky/scripts/ingv $url
mv "query?starttime=$date""T00:00:00&endtime=$date2""T23:59:59&minmag=5&maxmag=10&mindepth=-10&maxdepth=1000&minlat=-90&maxlat=90&minlon=-180&maxlon=180&minversion=100&orderby=time-asc&timezone=UTC&format=text&limit=10000" ~/.config/conky/scripts/ingv


cat ~/.config/conky/scripts/ingv | cut -d '|' -f 2,11,13 | cut --complement -c 11-26 | sed '1d' > ~/.config/conky/scripts/ingv2
